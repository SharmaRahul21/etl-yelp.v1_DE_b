# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['yelp_etl_pkg']

package_data = \
{'': ['*'], 'yelp_etl_pkg': ['.pytest_cache/*', '.pytest_cache/v/cache/*']}

install_requires = \
['DateTime>=4.3,<5.0',
 'numpy>=1.19.5,<2.0.0',
 'pandas>=1.2.1,<2.0.0',
 'poetry>=1.1.4,<2.0.0',
 's3fs>=0.5.2,<0.6.0']

setup_kwargs = {
    'name': 'yelp-etl-pkg',
    'version': '0.1.0',
    'description': 'Yelp DataEngineering Exercise - ETL Pipeline',
    'long_description': None,
    'author': 'Rahul Sharma',
    'author_email': 'rahul_sharma21@outlook.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
